
function NoSlowdownOnHit.init()
    player.data.noSlowdownOnHit = true
end
