

function ExplosionFireParticle.initSystem()
    addAttribute("moveSpeed", "vec2")
    addAttribute("uvStart", "vec2")
    addAttribute("uvSize", "vec2")
    addAttribute("uvShift", "vec2")
    addAttribute("color", "float")
    addAttribute("maxTime", "float")
    addAttribute("maxScale", "float")
end

