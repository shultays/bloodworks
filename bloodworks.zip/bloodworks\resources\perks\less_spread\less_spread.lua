
function LessSpread.init(level)
    player.gunSpreadMultiplier:addBuff(0.6)
end

