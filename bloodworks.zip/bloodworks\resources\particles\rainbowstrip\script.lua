

function RainbowStrip.initSystem()
end


function RainbowStrip.setDefaultArgs(args)
end

function RainbowStrip.addParticle(params, pos, args)

end