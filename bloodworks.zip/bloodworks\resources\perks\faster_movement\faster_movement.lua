
function FasterMovement.init()
    player.maxSpeed:addBuff(1.2)
end
