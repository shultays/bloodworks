
function FasterMovement.init()
    player.maxSpeed:addBuff(1.25)
end
