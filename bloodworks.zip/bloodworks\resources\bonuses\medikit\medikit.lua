
function MediKit.spawn(bonus, pos)
    player:doHeal(30)
    playSound({path = MediKit.basePath .. "heal.ogg", volume = 1.5})
end



