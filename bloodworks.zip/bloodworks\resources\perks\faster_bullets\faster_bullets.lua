
function FasterBullets.init()
    player.bulletSpeedMultiplier:addBuff(1.35)
end
