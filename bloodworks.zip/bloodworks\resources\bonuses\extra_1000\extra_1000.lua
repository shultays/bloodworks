
function Extra1000.spawn(bonus, pos)
    addScore(1000)
    playSound({path = Extra1000.basePath .. "score.ogg", volume = 0.5})
end



