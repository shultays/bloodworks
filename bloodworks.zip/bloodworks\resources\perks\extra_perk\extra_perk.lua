
function ExtraPerk.init(level)
    missionData.perkPerLevel = missionData.perkPerLevel + 1
end

