
function ExperienceBoostPerk.init()
    player.monsterExperienceMultiplier:addBuff(1.5)
end
