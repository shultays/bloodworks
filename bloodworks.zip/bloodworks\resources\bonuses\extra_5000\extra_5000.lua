
function Extra5000.spawn(bonus, pos)
    addScore(5000)
    playSound({path = Extra5000.basePath .. "score.ogg", volume = 0.5})
end



