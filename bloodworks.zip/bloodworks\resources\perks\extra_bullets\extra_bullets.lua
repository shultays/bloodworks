
function ExtraBullets.init(level)
    player.clipCountMultiplier:addBuff(1.2)
end

