
function FasterShoot.init()
    player.shootSpeedMultiplier:addBuff(0.8)
end
