

function StripTestParticle.initSystem()
end


function StripTestParticle.setDefaultArgs(args)
end

function StripTestParticle.addParticle(params, pos, args)

end