

function RocketSmokeParticle.initSystem()
    addAttribute("color", "float")
    addAttribute("moveSpeed", "vec2")
    addAttribute("initialScale", "float")
    addAttribute("scaleSpeed", "float")
    addAttribute("initialAlpha", "float")
    addAttribute("fadeOutSpeed", "float")
end
