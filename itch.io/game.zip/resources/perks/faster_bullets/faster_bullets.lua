
function FasterBullets.init()
	player.bulletSpeedMult = player.bulletSpeedMult * 1.35
end
