
function FasterMovement.init()
	player.moveSpeedMult = player.moveSpeedMult * 1.20
end
