
function NoSlowdownOnHit.init()
	player.slowdownOnHit = false
end
