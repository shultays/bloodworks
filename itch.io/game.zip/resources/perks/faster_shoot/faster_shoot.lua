
function FasterShoot.init()
	player.shootSpeedMult = player.shootSpeedMult * 0.8
end
