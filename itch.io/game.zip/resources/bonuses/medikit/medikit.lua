
function MediKit.spawn(pos)
	player:doHeal(25)
end



