
function Experience.spawn(pos)
	player:gainExperience(math.floor(player.experienceForNextLevel / 10))
end



